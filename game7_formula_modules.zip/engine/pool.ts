import RAW from '../data/players_stats.json'
import type { Player } from './types'

/**
 * The pool: data/build_ratings.py output, loaded verbatim. `name` is the game's
 * identity, so the handful of real same-name players (two Eddie Johnsons, …)
 * get their peak year appended — the only edit made to the data, and it never
 * touches a rating.
 */
/**
 * The pool: data/build_ratings.py output, loaded verbatim. One entry per
 * player-SEASON ("LeBron James '13"); the pipeline guarantees unique names.
 */
export const PLAYERS: Player[] = RAW as Player[]

/**
 * Short readable archetype, derived purely from the ratings.
 *
 * Ordered most specific first. Every rule that names a strength requires that
 * strength to be good in absolute terms, never merely better than the same
 * player's other numbers — otherwise a 62-inside, 18-outside centre reads as a
 * "post scorer" because he is even worse from range, and a guard with 60
 * perimeter D reads as a stopper because his rim protection is worse still.
 */
export function archetype(p: Player): string {
  const a = p.attrs
  const paint = a.rim
  const mid = a.mid
  const three = a['3pt']
  const zone = Math.max(three, paint, mid)
  const big = p.big
  const h = a.height
  // Tree v2, 43 rules. Evaluated top-down, FIRST MATCH WINS. Names describe style,
  // never tier — quality is OVR's job. Thresholds are tunable; the order is law.
  if (a.passqual >= 85 && a.playvol >= 70 && a.perdef >= 80 && zone < 55) return 'Defensive playmaker'
  if (a.playvol >= 95 && a.passqual >= 90 && a.ballsec >= 80) return 'Point god'
  if (a.playvol >= 95 && a.usage >= 90) return 'Engine'
  if (a.playvol >= 85 && a.drb >= 80 && a.usage >= 88 && !big) return 'Triple-double threat'
  if (h >= 78 && a.playvol >= 85 && a.passqual >= 78 && !big) return 'Point forward'
  if (a.playvol >= 85 && a.passqual >= 85 && a.usage < 90) return 'Floor general'
  if (a.playvol >= 90 && a.efficiency < 55) return 'Floor raiser'
  if (big && a.rimprot >= 90 && p.o_ovr >= 80) return 'Two-way anchor'
  if (big && three >= 65 && a.rimprot >= 85) return 'Unicorn'
  if (big && a.passqual >= 80) return 'Post hub'
  if (p.o_ovr >= 85 && p.d_ovr >= 85) return 'Two-way star'
  if (!big && p.o_ovr >= 78 && p.d_ovr >= 85) return 'Two-way wing'
  if (a.usage >= 90 && a.efficiency >= 75 && paint >= 55 && mid >= 55 && three >= 55) return 'Three-level'
  if (mid >= 85 && three < 40 && a.usage >= 90) return 'Midrange maestro'
  if (!big && paint >= 80 && a.fouldraw >= 85 && three < 45) return 'Slasher'
  if (paint >= 90 && a.usage >= 90 && three < 40) return 'Freight train'
  if (big && paint >= 80 && a.fouldraw >= 80 && a.ft < 60) return 'Tank'
  if (a.fouldraw >= 90 && a.ft >= 85) return 'Foul merchant'
  if (a.usage >= 85 && a.efficiency >= 75 && a.playvol < 50) return 'Microwave'
  if (h < 75 && a.usage >= 80) return 'Spark plug'
  if (!big && paint >= 85 && h >= 78) return 'Bully ball'
  if (three >= 90 && a.usage >= 55) return 'Flamethrower'
  if (three >= 90 && a.usage < 40) return 'Sniper'
  if (a.ft >= 95 && three >= 75) return 'Deadeye'
  if (three >= 80 && a.playvol < 40 && a.usage < 55) return 'Catch-and-shoot wing'
  if (big && three >= 70) return 'Stretch big'
  if (big && mid >= 75) return 'Pick-and-pop big'
  if (a.orb >= 90 && a.drb >= 90) return 'Glass cleaner'
  if (big && paint >= 75 && a.usage < 20 && a.orb >= 60) return 'Lob threat'
  if (big && a.orb >= 85 && a.usage < 40) return 'Energy big'
  if (big && paint >= 70 && three < 25 && a.fouldraw >= 70) return 'Rim runner'
  if (big && a.rimprot >= 70 && a.discipline < 35) return 'Enforcer'
  if (a.rimprot >= 90 && a.usage < 55) return 'Anchor'
  if (a.perdef >= 90 && a.usage < 70 && p.o_ovr < 80) return 'Stopper'
  if (h < 76 && a.perimdisrupt >= 90) return 'Pest'
  if (a.perimdisrupt >= 85 && a.perdef < 55) return 'Gambler'
  if (a.usage < 55 && three >= 70 && a.passqual >= 80 && a.perdef >= 75) return 'Connector'
  if (a.playvol >= 70 && a.playvol <= 89 && a.passqual >= 70 && a.usage >= 55 && a.usage <= 85) return 'Secondary creator'
  if (a.ballsec >= 90 && a.usage < 50) return 'Safety valve'
  if (mid >= 70 && three < 45 && a.usage < 60) return 'Mid glue'
  if (mid >= 75 && three < 20) return 'Throwback'
  if (paint >= 70 && mid >= 65 && three < 40 && a.playvol < 60) return 'Post scorer'
  const solid = [zone, a.playvol, Math.max(a.perdef, a.rimprot), Math.max(a.orb, a.drb)].filter((v) => v >= 60).length
  if (Math.max(zone, a.playvol, a.passqual, a.perdef, a.rimprot, a.orb, a.drb) < 88 && solid >= 4) return 'All-around'
  return 'Balanced'
}
