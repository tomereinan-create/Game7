"""OVR = 0.65 x talent + 0.35 x engine-derived marginal value (class-relative).
The marginal value drops the player into his best-fit slot of a league-average five and measures the
added matchup margin vs that same five, so usage economy, spacing, anchor logic and hunted-man all price in;
it is percentile-normalised within position class (bigs vs perimeter) before blending.
FINAL pipeline step: build_ratings.py -> compute_ovr.py. Reads and rewrites players_stats.json in place
(the 10,000-season file; names carry the year).  python compute_ovr.py [path/to/players_stats.json]"""
import bisect, io, json, re, sys

# team_rating.py's functions only — its demo section at the bottom expects the peak-only file.
src = io.open('team_rating.py', encoding='utf-8').read()
head = src.split("P = {p['name']")[0]
tail = src[src.index('# ---------- DEFENSE v2'):]
tail = re.sub(r"^print\(.*\n", "", tail, flags=re.M)
tail = re.sub(r"^for name, L in LINEUPS.*\n(^[ \t].*\n)*", "", tail, flags=re.M)
exec(head); exec(tail)

W_TALENT, W_MARG, W_SKILL = 0.50, 0.30, 0.22   # the blend knobs (batch 2: skill mix joins)

path = sys.argv[1] if len(sys.argv) > 1 else 'players_stats.json'
players = json.load(io.open(path, encoding='utf-8'))
for p in players:
    best = -99
    for i in range(5):
        L = REF_FIVE[:i] + [p] + REF_FIVE[i + 1:]
        m = matchup_margin(L, REF_FIVE)
        if m > best: best = m
    p['_raw'] = best

import os
_here = os.path.dirname(os.path.abspath(__file__))
_cands = [os.path.join(os.path.dirname(os.path.abspath(path)), 'stats.json'), os.path.join(_here, '..', 'src', 'data', 'stats.json')]
_stats_path = next((c for c in _cands if os.path.exists(c)), None)
if not _stats_path: raise SystemExit('stats.json (lifetime positions) not found - the guard rule needs it')
_POS = {k: (v or {}).get('pos') or [] for k, v in json.load(io.open(_stats_path, encoding='utf-8')).items()}
def is_big(p):
    # compound: rim protection alone doesn't make you a big (long-armed wings tripped the old threshold),
    # and a lifetime guard (PG/SG by Basketball-Reference, never PF/C) is never a big whatever his shape -
    # Payton-type post-defending guards were being graded as anchors
    pos = _POS.get(p['name'], [])
    if pos and ('PG' in pos or 'SG' in pos) and not ('C' in pos or 'PF' in pos): return False
    a = p['attrs']; return (a['rimprot'] >= 55 and a['3pt'] < 45) or (a['rim'] >= 60 and a['3pt'] < 40) or a['rimprot'] >= 80   # stretch bigs classify by deterrence, whatever their range

# offensive / defensive sub-ratings: SKILL composites from the attribute sheet
# (marginal-in-average-team measures fit value, not end-skill - wrong tool for display)
def o_score(p):
    # recal batch 2: orb IS offense (second chances); fouldraw only scores through FT (multiplicative,
    # the clank tax); passing weights eased so scoring bigs aren't taxed for a skill their shape never used;
    # volume x efficiency is a SIGNATURE, not two facts (the interaction term restores Curry's O99)
    a = p['attrs']; z = sorted([a['3pt'], a['rim'], a['mid']], reverse=True)
    std = (0.28*z[0] + 0.09*z[1] + 0.15*a['efficiency'] + 0.11*a['usage']
          + 0.10*a['playvol'] + 0.08*a['passqual'] + 0.03*a['ballsec']
          + 0.05*(a['fouldraw']*a['ft']/100) + 0.03*a['orb']
          + 0.08*(a['usage']*a['efficiency']/100))
    # SPECIALIST MASTERY floor (the principle's third appearance: 3PT deadeye -> zone deadeye -> the card):
    # a 96-zone/95-efficiency pure specialist is a weapon, not a 61
    if z[0] >= 80:
        std = max(std, 0.44*z[0] + 0.25*a['efficiency'] + 0.05*a['ballsec'])
    # MAESTRO branch: zone mastery AT LOAD - inefficient masters floored on craft, not efficiency
    if z[0] >= 82 and a['usage'] >= 90 and a['efficiency'] >= 45:
        std = max(std, 0.40*z[0] + 0.12*a['usage'] + 0.10*a['ballsec'] + 0.08*(a['fouldraw']*a['ft']/100) + 0.05*a['playvol'] + 0.20*a['efficiency'])
    # CREATOR branch: creation AT LOAD carries teams
    if a['playvol'] >= 95 and a['usage'] >= 90:
        std = max(std, 0.34*a['playvol'] + 0.14*a['usage'] + 0.13*a['passqual'] + 0.18*z[0] + 0.05*a['efficiency'] + 0.05*(a['fouldraw']*a['ft']/100))
    return std
def d_score(p):
    # class-dependent: bigs' defensive votes route to rimprot by design, so perdef understates them;
    # perimeter keeps the round-1 perdef-heavy mix (perdef IS the complete defensive verdict)
    a = p['attrs']
    if is_big(p):
        return 0.40*a['perdef'] + 0.40*a['rimprot'] + 0.17*a['drb'] + 0.03*a['discipline']   # drb weight up: rebounding credit now lives here, not inside rimprot
    base = 0.70*a['perdef'] + 0.15*a['perimdisrupt'] + 0.08*a['drb'] + 0.07*a['discipline']
    # size modifier: a 6'0 defender guards one matchup; tall stoppers switch. Guard-quota All-D
    # selections are real evidence, but size caps the ceiling. Bites only truly small defenders.
    return base * min(1.0, 0.94 + 0.06*(a.get('height', 76) - 71)/7)
for cls in (True, False):
    grp = sorted(p['_raw'] for p in players if is_big(p) == cls)
    for p in players:
        if is_big(p) != cls: continue
        pct = bisect.bisect_left(grp, p['_raw']) / max(1, len(grp) - 1)
        p['_marg'] = 40 + 59 * pct
for p in players:
    p['big'] = is_big(p)   # the app labels from this; is_big lives here and nowhere else
    p['o_ovr'] = int(min(99, round(o_score(p) * 1.10)))
    p['d_ovr'] = int(min(99, round(d_score(p) * 1.10)))
    # OVR now includes the skill mix: BPM-based talent overpaid empty-calorie profiles
    # (assist collectors at bad efficiency read 83 while the engine punished them every possession)
    skill = 0.55*p['o_ovr'] + 0.45*p['d_ovr']
    a = p['attrs']
    raw = W_TALENT * p['talent'] + W_MARG * p['_marg'] + W_SKILL * skill
    # EMPTY-VOLUME TAX: the negative side of the usage x efficiency signature - extreme load at
    # mediocre efficiency costs OVR (capped at 5)
    raw -= min(5.0, 0.06 * max(0, a['usage'] - 72) * max(0, 58 - a['efficiency']))   # threshold 72: real load, not just max load
    # recal 3: offense gates the ceiling (a defense-first perimeter player stops one man), but elite
    # defense keeps a floor; an elite anchor is a defensive SYSTEM, so bigs are effectively exempt
    cap = max(p['o_ovr'] + 10, 0.80 * p['d_ovr']) if not is_big(p) else p['o_ovr'] + 40
    p['ovr'] = int(min(99, cap, round(raw)))
    del p['_raw']; del p['_marg']
json.dump(players, io.open(path, 'w', encoding='utf-8'), separators=(',', ':'))

rank = sorted(players, key=lambda x: -x['ovr'])
print("TOP 12 BY OVR:")
for p in rank[:12]: print(f"  {p['name']:28s} OVR {p['ovr']}  (talent {p['talent']})")
print("\nARCHETYPE CHECKS:")
for nm in ["Dennis Rodman '92", "Trae Young '22", "Steve Kerr '96", "Shane Battier '06", "Dereck Lively II '24", "Rudy Gobert '19", "Draymond Green '16", "Carmelo Anthony '14", "Stephen Curry '16", "LeBron James '13", "Michael Jordan '88", "Kareem Abdul-Jabbar '80"]:
    m = [p for p in players if p['name'] == nm]
    if m: p = m[0]; print(f"  {p['name']:28s} OVR {p['ovr']}  O {p['o_ovr']}  D {p['d_ovr']}  paint {p['attrs']['rim']} mid {p['attrs']['mid']}  (talent {p['talent']})")
